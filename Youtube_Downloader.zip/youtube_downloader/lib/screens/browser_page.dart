
import 'package:flutter/material.dart';

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {

  final link = 'https://www.youtube.com';

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}