//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_youtube_downloader/FlutterYoutubeDownloaderPlugin.h>)
#import <flutter_youtube_downloader/FlutterYoutubeDownloaderPlugin.h>
#else
@import flutter_youtube_downloader;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterYoutubeDownloaderPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterYoutubeDownloaderPlugin"]];
}

@end
