package com.example.youtube_downloader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
